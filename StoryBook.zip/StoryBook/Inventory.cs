using System;
using System.Collections.Generic;

namespace StoryBook
{
    public class Inventory
    {
        public Sword sword {get; set;}
        public Potion potion {get; set;}
        public Inventory()
        {
            sword = new Sword();
            potion = new Potion();
        }
    }

    public class Potion
    {
        public string name = "Potion";
        public bool obtained = false;
        public bool equipped = false;
        public int heal = 5;
        public int weight = 2;
    }

    public class Sword
    {
        public string name = "Sword";
        public bool obtained = true;
        public bool equipped = false;
        public int attack = 4;
        public int defense = 1;
        public int weight = 5;
    }
}