using System;
using System.Collections.Generic;
using System.Linq;

namespace StoryBook
{
    public class Combat
    {
        public static void start(Player player, string enemyType, int enemyCount)
        {
            // for(var i = 0; i < enemyCount; i++)
            // {

            // }
            var enemy = new Enemy(enemyType);

            Random rnd = new Random();
            int intitative = rnd.Next(10);
            if(intitative > 5)
            {
                System.Console.WriteLine("\nYou attack first!");
                playerAttack(player, enemy, enemyCount);
            }
            else
            {
                System.Console.WriteLine("\nThe enemy attacks first!");
                enemyAttack(player, enemy, enemyCount);
            }
        }
        public static void playerAttack(Player player, Enemy enemy, int enemyCount)
        {
            if(enemyCount == 0)
            {
                return;
            }
                if(player.health <= 0)
                {
                    System.Console.WriteLine("\nYou have died!");
                    Program.menu();
                }
                else
                {
                    System.Console.WriteLine("1: Open Inventory");
                    System.Console.WriteLine("2: View Health");
                    if(player.equippedItem != ""){ System.Console.WriteLine($"3: Use {player.equippedItem}");}

                    System.Console.WriteLine("What action do you take?");
                    var inputChoice = Console.ReadLine();

                    if(inputChoice == "1")
                    {
                        player.ViewInventory();
                    }
                    else if(inputChoice == "2")
                    {
                        System.Console.WriteLine($"You have {player.health} hitpoints");
                        playerAttack(player, enemy, enemyCount);
                    }
                    else if(inputChoice == "3" && player.equippedItem != "")
                    {
                        Random chance = new Random();
                        int playerAttackChance = chance.Next(player.playerInventory.sword.attack);
                        int enemyDefenseChance = chance.Next(enemy.defense);
                        var dmg = playerAttackChance - enemyDefenseChance;
                        enemy.health = enemy.health - dmg;
                        System.Console.WriteLine($"\nYou strike the {enemy.name} for {dmg} damage");
                    }
                    else
                    {
                        System.Console.WriteLine("Invalid choice!");
                        playerAttack(player, enemy, enemyCount);
                    }

                    enemyAttack(player, enemy, enemyCount);
                }
        }
        public static void enemyAttack(Player player, Enemy enemy, int enemyCount)
        {
            var turns = 0;

            while(enemyCount > turns)
            {
                if(enemy.health <= 0)
                {
                    System.Console.WriteLine($"You defeat the {enemy.name}!");
                    enemyCount = enemyCount - 1;
                    break;
                }
                else if(enemy.health > 0)
                {
                    Random chance = new Random();
                    int enemyAttackChance = chance.Next(enemy.attack);
                    int playerDefenseChance = chance.Next(player.playerInventory.sword.defense);
                    var dmg = enemyAttackChance - playerDefenseChance;
                    player.health = player.health - dmg;
                    System.Console.WriteLine($"\nThe {enemy.name} strikes you for {dmg} damage\n");
                }
                 turns++;
            }
            //System.Console.WriteLine($"{enemyCount} left");
            playerAttack(player, enemy, enemyCount);
        }
    }
}