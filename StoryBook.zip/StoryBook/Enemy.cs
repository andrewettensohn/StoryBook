namespace StoryBook
{
    public class Enemy
    {
        public string name;
        public string actionDescription;
        public int health;
        public int attack;
        public int defense;
        public Enemy(string enemyType)
        {
            if(enemyType == "Goblin")
            {
                name = "goblin";
                actionDescription = "The goblin attacks with his shortsword!";
                health = 3;
                attack = 3;
                defense = 1;
            }
            else if (enemyType == "Goblin Chief")
            {
                name = "goblin chief";
                actionDescription = "The goblin chief attacks with his scimatar!";
                health = 8;
                attack = 6;
                defense = 3;
            }
            else if (enemyType == "Bugbear")
            {
                name = "bugbear";
                actionDescription = "The bugbear attacks with his morning star!";
                health = 10;
                attack = 6;
                defense = 2;
            }
            else if (enemyType == "Skeleton")
            {
                name = "skeleton";
                actionDescription = "The skeleton attacks with his axe!";
                health = 5;
                attack = 6;
                defense = 2;
            }
        }
    }
}