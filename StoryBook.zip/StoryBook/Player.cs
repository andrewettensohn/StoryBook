using System.Collections.Generic;
using System;

namespace StoryBook
{
    public class Player
    {
        public Player(string characterName)
        {
            name = characterName;
            health = 10;
            playerInventory = new Inventory();
            equippedItem = "";

        }
        public void ViewInventory()
        {
            var itemList = new List<string>();

            var sword = playerInventory.sword;
            var potion = playerInventory.potion;

            //var potion1 = playerInventory.potion;

            // foreach(var value in playerInventory.GetType().GetProperties())
            // {
            //     //var potion1 = playerInventory.potion;

            //     System.Console.WriteLine(value.Name);
            //     System.Console.WriteLine(value.GetValue(playerInventory, null));
            // }

            if(sword.obtained == true)
            {
                itemList.Add(sword.name);
            }

            if(potion.obtained == true)
            {
                itemList.Add(potion.name);
            }

            for(var i = 0; i < itemList.Count; i++)
            {
                System.Console.WriteLine($"\nYou have a {itemList[i]}");
            }

            System.Console.WriteLine("1: Use an item?");
            var inputChoice = Console.ReadLine();

            if(inputChoice == "1")
            {
                //System.Console.WriteLine("\nWhich item do you want to equip?");
                for(var i = 0; i < itemList.Count; i++)
                {
                    System.Console.WriteLine($"{i}:{itemList[i]}");
                }
                inputChoice = Console.ReadLine();
                var inputChoiceToInt = int.Parse(inputChoice);
                System.Console.WriteLine($"\nYou have equipped a {itemList[inputChoiceToInt]}");
                
                

                // for(var i = 0; i < itemList.Count; i++)
                // {
                //     if(inputChoice == itemList[i])
                //     {
                //         System.Console.WriteLine($"\nYou have equipped a {itemList[i]}");
                //         playerInventory.sword.equipped = true;
                //         equippedItem = $"{itemList[i]}";
                //         return;
                //     }
                // }
        }
        public string name;
        public double health;
        public Inventory playerInventory;
        public string equippedItem;
    }
}